Author: CodexWorld
Author URL: http://www.codexworld.com/
Author Email: contact@codexworld.com
Tutorial Link: http://www.codexworld.com/online-poll-voting-system-php-mysql/

============ Instruction ============
1. Create a database (for example, poll_system) and import the "poll_system.sql" file into this database.
2. Open the "Poll.php" file => change the $dbHost, $dbUser, $dbPwd, and $dbName variable's value as per your phpMyAdmin details.
3. Browse the "index.php" file on the browser and check the Online Poll System functionality.


============ May I Help You ===========
If you have any query about this script, send us by posting a comment here - http://www.codexworld.com/online-poll-voting-system-php-mysql/#respond